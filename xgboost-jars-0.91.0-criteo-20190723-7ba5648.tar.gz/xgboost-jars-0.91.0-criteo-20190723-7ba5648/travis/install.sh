set -xe

python ./install_xgboost.py